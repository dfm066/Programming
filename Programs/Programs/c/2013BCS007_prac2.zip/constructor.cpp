#include<iostream>
#include<string>
using namespace std;
class strng
{
  const  char *str;

    public:
        strng()
        {
            str=new char;
        }

        strng(const char *s)
        {
            str=s;
        }
        strng(strng &o)
        {
            str=o.str;
        }
        void display()
        {
            cout<<str;
        }
        ~strng()
        {
            delete str;
        }
};
int main()
{
strng o1,o2;
char *name=new char;
//cin>>name;
//o1=name;
o1="shubham";
o2=o1;
o1.display();
o2.display();
return 0;
}
