#include<stdio.h>
#include<stdlib.h>
struct inf
{
	int age;
	char name[20];
};
int main()
{
	struct inf p;
	FILE *fp;
	int i=1;
	fp=fopen("example.txt","w");
	while(i<=5)
	{
		printf("\nEnter name and age of persons");
		scanf("%s %d",p.name,&p.age);
		fwrite(&p,sizeof(p),1,fp);
		i++;
	}
	fclose(fp);
	return 0;
}

