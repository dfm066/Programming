#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct data
{
	int age;
	char name[20];
}DATA;
typedef struct bin
{
	DATA data;
	struct bin *left,*right;
}BIN;
void add_BST(BIN **st,struct data d)
{
	BIN *a=(BIN *)malloc(sizeof(BIN)),*ptr=*st;
	a->data.age=d.age;
	strcpy(a->data.name,d.name);
	a->left=a->right=NULL;
	//printf("%s %d",a->data.name,a->data.age);
	if(*st==NULL)
		*st=a;
	else
	{
		while(1)
		{
			if(a->data.age<ptr->data.age)
			{
				if(ptr->left==NULL||ptr->right==NULL)
					break;
				ptr=ptr->left;			
			}			
			else
			{
				if(ptr->left==NULL||ptr->right==NULL)
					break;
				ptr=ptr->right;			
			}
		}
		if(a->data.age<ptr->data.age)
			ptr->left=a;
		else
			ptr->right=a;
	}
}
void inorder(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		inorder(st->left);		
		printf("%4d %s\n",st->data.age,st->data.name);
		inorder(st->right);
	}
}
void highest(BIN *a)
{
	while(1)
	{
		if(a->right!=NULL)
			a=a->right;
		else
			break;
	}
	printf("\n%s %4d",a->data.name,a->data.age);
}
void lowest(BIN *a)
{
	while(1)
	{
		if(a->left!=NULL)
			a=a->left;
		else
			break;
	}
	printf("\n%s %4d\n",a->data.name,a->data.age);
}
void reverse(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		reverse(st->right);
		printf("\n%4d %s",st->data.age,st->data.name);
		reverse(st->left);
	}
}
		
