#include"Binary_T.h"
int main()
{
	int d,opt;
	BIN *p=NULL;
	while(1)
	{
		printf("\n1.Add Node in Tree\n2.Preorder Traversal\n3.Postorder Traversal\n4.Inorder Traversal\n5.No of nodes\n6.\n7.\n8.");
		scanf("%d",&opt);
		if(opt>=9)
			break;
		switch(opt)
		{
			case 1:	printf("\nEnter data");
				scanf("%d",&d);
				addNode(&p,d);
				break;
			case 2:	preorder(p);
				break;
			case 3:	postorder(p);
				break;
			case 4:	inorder(p);
				break;
			case 5:	countN(p);
				break;
			case 6:	inorderNON(p);
				break;
			case 7:	preorderNON(p);
				break;
			case 8:	postorderNON(p);
				break;
		}
	}
	return 0;
}


