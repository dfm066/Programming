#include<iostream>
#include<iomanip>
using namespace std;
#define n 2
class patients
{
		char *name;
		int d[2],m[2],y[2];
		char *disease;
	public:
		void getdata();
		void enterdate(int );
		inline void display();
};

class pediatric:public patients
{
    int age;
    public:
        void getage()
        {
            cin>>age;
        }
        void putpediatric()
        {
            if(age<12)
                display();
        }
};
void patients::getdata()
{
	 int i=0;
	cout<<"enter name of patient";
	name=new char;
	cin>>name;
	cout<<"enter date of admission";
	enterdate(i);
	cout<<"enter name of desease";
	disease=new char;
	cin>>disease;
	i++;
	cout<<" enter date of discharge";
	enterdate(i);
}

void patients::display()
{
    static int i;
    cout<<endl<<setw(10)<<name<<setw(10)<<d[0]<<"/"<<m[0]<<"/"<<y[0]<<setw(10)<<disease<<setw(10)<<d[1]<<"/"<<m[1]<<"/"<<y[1];

}
void patients :: enterdate(int i)
{
	cout<<"\nenter date/month/year" ;
	cin>>d[i]>>m[i]>>y[i];

    if(m[i]>12)
    {
        cout<<"invalid date";
        enterdate(i);
    }

	if((m[i]==4||m[i]==6||m[i]==9||m[i]==11)&&d[i]>30)
	{
		cout<<"invalid date";
		d[i]=0;m[i]=0;y[i]=0;
		enterdate(i);
	}

	if((m[i]==1||m[i]==3||m[i]==5||m[i]==7||m[i]==8||m[i]==10||m[i]==12)&&d[i]>31)
	{
		cout<<"invalid date";
		d[i]=0;m[i]=0;y[i]=0;
		enterdate(i);
	}

	if(y[i]%4==0&&m[i]>2&&d[i]>29)

	{
		cout<<"invalid date";
		d[i]=0;m[i]=0;y[i]=0;
		enterdate(i);
	}

	if(y[i]%4!=0&&m[i]==2&&d[i]>28)
	{
		cout<<"invalid date";
		d[i]=0;m[i]=0;y[i]=0;
		enterdate(i);
	}
	return;
}
int main()
{
    pediatric p[n];
    int i=0;
    while(i<n)
    {
        p[i].getdata();
        cout<<"\nenter age";
        p[i].getage();
        i++;
    }
    cout<<"pediatric patients are\n";
    while(i>0)
    {
        p[n-i].putpediatric();
        i--;
    }
}
