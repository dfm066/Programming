#include<iostream>
#include<math.h>
using namespace std;


class cord_pt
{
private:
float x,y;

public:
void getx()
{
cout<<"\n Enter coordinate of x = ";
cin>>x;
}
void gety()
{
cout<<"\n Enter coordinate of y = ";
cin>>y;
}

float setx()
{
return x;
}
float sety()
{
return y;
}

void showxy()
{
cout<<"\nX=="<<x<<"\nY=="<<y;
}


};

class distanc : public cord_pt
{
private:
float z;
float a,b;
public:


float dist()
{
 b=sety();
a=setx();
z=sqrt(pow(a,2)+pow(b,2));
return z;
}

};

int main()
{
  distanc a;
  //cord_pt b;

  a.getx();
  a.gety();
  a.showxy();
  cout<<"\nDistance from centre = "<<a.dist();


  return 0;


}
