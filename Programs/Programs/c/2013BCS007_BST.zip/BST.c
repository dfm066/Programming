#include<stdio.h>
#include"BST.h"
int main()
{
	FILE *fp;
	struct data d; 
	BIN *st=NULL;
	fp=fopen("example.txt","r");
	if(fp==NULL)
	{	printf("\nUnable to open file");
		return 0;
	}
	while(1)
	{
		fread(&d,sizeof(d),1,fp);
		if(feof(fp))
			break;
		add_BST(&st,d);
	}
	inorder(st);
	printf("\nEldest person");
	highest(st);
	printf("\nYoungest person");
	lowest(st);
	printf("\nDescending order ");
	reverse(st);
	fclose(fp);	
	return 0;
}
