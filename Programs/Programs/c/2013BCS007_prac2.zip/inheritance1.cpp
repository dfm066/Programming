#include<iostream>
using namespace std;
class student
{
    char *name;
    public:
        student()
        {
            name=new char;
        }
        void getname();
        void putname();
};
class test:public student
{
    int marks1,marks2;
    public:
        void getmark();
        void putmark();
};
class result:public test
{
    public:
        void sturesult();

};

int main()
{
    student s;
    test t;
    result r;
    cout<<"name:";
    r.getname();
    cout<<"mark:";
    r.getmark();
    cout<<"result:\n";
    r.sturesult();
    return 0;

}
void student::getname()
{
cin>>name;
}
void student::putname()
{
    cout<<name;
}
void test::getmark()
{
    cin>>marks1>>marks2;
}
void test::putmark()
{
    cout<<endl<<marks1+marks2;
}
void result::sturesult()
{
    putname();
    putmark();
}
