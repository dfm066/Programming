#include<stdio.h>
#include"que.h"
#include"stk.h"
typedef struct bin
{
	int data;
	struct bin *left,*right;
}BIN;
QUE p;
void addNode(BIN **st,int d)
{
	BIN *a,*b=(BIN *)malloc(sizeof(BIN));
	b->data=d;
	b->left=b->right=NULL;
	if(*st==NULL)
		*st=b;
	else
	{
		a=quefront(&p);
		if(a->left==NULL)
		{	a->left=b;
			printf("\nLeft");
		}
		else
		{
			a->right=b;
			printf("\nright");
			dequeue(&p);
		}
	}
	enqueue(&p,b);
}
void preorder(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		printf("%4d",st->data);
		preorder(st->left);
		preorder(st->right);
	}
}
void inorder(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		inorder(st->left);
		printf("%4d",st->data);
		inorder(st->right);
	}
}
void postorder(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		postorder(st->left);
		postorder(st->right);
		printf("%4d",st->data);	
	}
}
int cnt=0;
void postCNT(BIN *st)
{
	if(st==NULL)
		return;
	else
	{
		postCNT(st->left);
		postCNT(st->right);
		cnt++;	
	}	
}
void countN(BIN *st)
{
	postCNT(st);
	printf("\nNo of nodes %d",cnt);
	cnt=0;	
	return;
}
void inorderNON(BIN *st)
{
	STACK *p=NULL;
	BIN *ptr=st;
	next: 	while(ptr!=NULL)
		{
			push(&p,ptr);
			ptr=ptr->left;
		}
		ptr=pop(&p);
		while(ptr!=NULL)
		{
			printf("%4d",ptr->data);
			if(ptr->right!=NULL)
			{
				ptr=ptr->right;
				goto next;
			}
			ptr=pop(&p);
		}
}
void preorderNON(BIN *st)
{
	STACK *p=NULL;
	BIN *ptr=st;
	while(ptr!=NULL)
	{
		printf("%4d",ptr->data);
		if(ptr->right!=NULL)
			push(&p,ptr->right);
		if(ptr->left!=NULL)
			ptr=ptr->left;
		else
			ptr=pop(&p);
	}
}		
void postorderNON(BIN *st)
{
	STACK *p=NULL;
	BIN *ptr=st;
	next:	while(ptr!=NULL)
		{
			push(&p,ptr);
			if(ptr->right!=NULL)
				push(&p,(ptr->right));
			ptr=ptr->left;
		}
		ptr=pop(&p);
		while(ptr>0)
		{
			printf("%4d",ptr->data);
			ptr=pop(&p);
		}
		if(ptr<0)
		{
			ptr=ptr;
			goto next;
		}
}
	
